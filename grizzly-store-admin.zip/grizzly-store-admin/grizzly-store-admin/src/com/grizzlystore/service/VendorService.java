package com.grizzlystore.service;

import com.grizzlystore.bean.Vendors;

public interface VendorService {
	public Vendors getVendorById(String id);

}
